create PROCEDURE SaveTabOperations
  (v_tab_id     IN cwm_sys_partoperations.TABLE_ID%TYPE,
   v_role_id    IN cwm_sys_partoperations.ROLE_ID%TYPE,
   v_operations IN cwm_sys_partoperations.OPERATIONS_ID%TYPE,
   v_filter     IN cwm_sys_partoperations.FILTER%TYPE,
   v_is_table   IN cwm_sys_partoperations.IS_TABLE%TYPE
  )
AS
  v_cnt NUMBER;
    No_result EXCEPTION;
  BEGIN
    SELECT count(*)
    INTO v_cnt
    FROM cwm_sys_partoperations
    WHERE table_id = v_tab_id AND role_id = v_role_id AND column_id = '*' AND is_table = v_is_table;
    IF v_cnt = 0
    THEN
      INSERT INTO cwm_sys_partoperations (ID, role_id, table_id, column_id, operations_id, filter, is_table)
      VALUES (seq_cwm_sys_partoperations.NEXTVAL, v_role_id, v_tab_id, '*', v_operations, v_filter, v_is_table);
      UPDATE cwm_sys_partoperations
      SET OPERATIONS_ID = v_operations, filter = v_filter
      WHERE table_id = v_tab_id AND is_table = v_is_table AND role_id = v_role_id;
    ELSE
      UPDATE cwm_sys_partoperations
      SET OPERATIONS_ID = v_operations, filter = v_filter
      WHERE table_id = v_tab_id AND is_table = v_is_table AND role_id = v_role_id;
    END IF;
    DBMS_OUTPUT.PUT_LINE('produce success');
    EXCEPTION
    WHEN no_result THEN
    DBMS_OUTPUT.PUT_LINE('?????????!');
    WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLCODE || '---' || SQLERRM);
  END SaveTabOperations;
/

