create trigger FLOW_RELATION
  after insert
  on JBPM4_EXECUTION
  DECLARE
    --父流程
    V_SUP_DBID_   JBPM4_FLOW_RELATION.SUP_DBID_%TYPE;
    V_SUP_EXC_ID_ JBPM4_FLOW_RELATION.SUP_EXC_ID_%TYPE;
    --子流程
    V_SUB_DBID_   JBPM4_FLOW_RELATION.SUB_DBID_%TYPE;
    V_SUB_EXC_ID_ JBPM4_FLOW_RELATION.SUB_EXC_ID_%TYPE;

    CURSOR CUR_SQL IS
      SELECT
        JE1.DBID_ AS SUPER_ID,
        JE1.ID_   AS SUPER_EXECID,
        JE2.DBID_ AS SUB_ID,
        JE2.ID_   AS SUB_EXECID
      FROM JBPM4_EXECUTION JE1, JBPM4_EXECUTION JE2
      WHERE JE2.PARENT_ = JE1.DBID_
            AND JE2.PARENT_ IS NOT NULL
            AND JE2.ID_ IS NOT NULL
            AND JE1.DBID_ IS NOT NULL
            AND JE1.ID_ IS NOT NULL
            AND JE2.ID_ || '-' || JE2.DBID_ NOT IN (SELECT JFR.SUB_EXC_ID_ || '-' || JFR.SUB_DBID_
                                                    FROM JBPM4_FLOW_BRANCH_RELATION JFR);

    CURSOR CUR_SQL_SUB IS
      SELECT
        DECODE(JE2.PARENT_, NULL, JE1.SUPEREXEC_, JE2.PARENT_)            AS SUPER_ID,
        DECODE(JE2.PARENT_, NULL, JE2.ID_, (SELECT T.ID_
                                            FROM JBPM4_EXECUTION T
                                            WHERE T.DBID_ = JE2.PARENT_)) AS SUPER_EXECID,
        JE1.DBID_                                                         AS SUB_ID,
        JE1.ID_                                                           AS SUB_EXECIDD
      FROM JBPM4_EXECUTION JE1, JBPM4_EXECUTION JE2
      WHERE JE1.SUPEREXEC_ = JE2.DBID_
            AND JE1.SUPEREXEC_ IS NOT NULL
            AND JE2.ID_ IS NOT NULL
            AND JE1.DBID_ IS NOT NULL
            AND JE1.ID_ IS NOT NULL
            --父流程实例ID-子流程(当前流程)
            AND DECODE(JE2.PARENT_, NULL, JE1.SUPEREXEC_, JE2.PARENT_) || '-' || JE1.DBID_ NOT IN
                (SELECT JFR.SUP_DBID_ || '-' || JFR.SUB_DBID_
                 FROM JBPM4_FLOW_RELATION JFR);
  BEGIN
    OPEN CUR_SQL;
    LOOP
      FETCH CUR_SQL
      INTO V_SUP_DBID_, V_SUP_EXC_ID_, V_SUB_DBID_, V_SUB_EXC_ID_;
      EXIT WHEN CUR_SQL%NOTFOUND;
      INSERT INTO JBPM4_FLOW_BRANCH_RELATION
      (ID, SUP_DBID_, SUP_EXC_ID_, SUB_DBID_, SUB_EXC_ID_)
      VALUES
        (SEQ_JBPM4_FLOW_BRANCH_RELATION.NEXTVAL,
         V_SUP_DBID_,
         V_SUP_EXC_ID_,
         V_SUB_DBID_,
         V_SUB_EXC_ID_);
    END LOOP;
    --关闭游标
    CLOSE CUR_SQL;

    OPEN CUR_SQL_SUB;
    LOOP
      FETCH CUR_SQL_SUB
      INTO V_SUP_DBID_, V_SUP_EXC_ID_, V_SUB_DBID_, V_SUB_EXC_ID_;
      EXIT WHEN CUR_SQL_SUB%NOTFOUND;
      INSERT INTO JBPM4_FLOW_RELATION
      (ID, SUP_DBID_, SUP_EXC_ID_, SUB_DBID_, SUB_EXC_ID_)
      VALUES
        (SEQ_JBPM4_FLOW_RELATION.NEXTVAL,
         V_SUP_DBID_,
         V_SUP_EXC_ID_,
         V_SUB_DBID_,
         V_SUB_EXC_ID_);
    END LOOP;
    --关闭游标
    CLOSE CUR_SQL_SUB;
  END;
/

