create FUNCTION cwm_relation_convert(main_ta_name VARCHAR2,
                                                main_id      VARCHAR2,
                                                sub_tab_name VARCHAR2)
  RETURN VARCHAR2 AS
  sub_table_ids VARCHAR2(1000);

  CURSOR cur_sql IS
    SELECT sub_data_id
    FROM cwm_relation_data
    WHERE main_table_name = main_ta_name
          AND main_data_id = main_id
          AND sub_table_name IN (SELECT s_table_name
                                 FROM cwm_tables
                                 START WITH s_table_name = sub_tab_name CONNECT BY PRIOR id = pid);
  CURSOR cur_sql_rev IS
    SELECT main_data_id
    FROM cwm_relation_data
    WHERE main_table_name = sub_tab_name
          AND sub_data_id = main_id
          AND sub_table_name IN (SELECT s_table_name
                                 FROM cwm_tables
                                 START WITH s_table_name = main_ta_name
                                 CONNECT BY PRIOR id = pid);
  ret           NUMBER;
  BEGIN
    sub_table_ids := '';
    FOR c IN cur_sql LOOP
      sub_table_ids := sub_table_ids || c.sub_data_id || ',';
    END LOOP;
    sub_table_ids := substr(sub_table_ids, 0, length(sub_table_ids) - 1);
    IF sub_table_ids IS NOT NULL
    THEN
      sub_table_ids := sub_table_ids || ',';
    END IF;
    FOR c IN cur_sql_rev LOOP
      SELECT INSTR(sub_table_ids, c.main_data_id)
      INTO ret
      FROM dual;
      IF ret IS NULL OR ret = 0
      THEN
        sub_table_ids := sub_table_ids || c.main_data_id || ',';
      END IF;
    END LOOP;
    sub_table_ids := substr(sub_table_ids, 0, length(sub_table_ids) - 1);
    RETURN sub_table_ids;
  END;
/

